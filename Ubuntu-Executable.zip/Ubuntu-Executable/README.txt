To launch bot open desired folder in terminal and run ./startBot.sh command
